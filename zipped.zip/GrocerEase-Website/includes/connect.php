<?php

$con = mysqli_connect("localhost", "root", "", "grocerease");
if (!$con) {
    die(mysqli_error($con));
}
?>