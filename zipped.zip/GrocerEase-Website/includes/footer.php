<div class="bg-success p-3 text-center text-light ">
    <p><b>All rights reserved</b>
        &copy;- <b>Designed By Team GrocerEase</b> </p>
</div>